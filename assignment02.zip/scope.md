# PROJECT SCOPE STATEMENT

**Project Name:** Personal Introduction Webpage
**Completed by:** Casey Trejo
**Projected Start:** June 21, 2026
**Projected Duration:** 1 day

---

## PROJECT PURPOSE:

To create a simple personal introduction webpage that meets the requirements of Project 01.

---

## PROJECT DESCRIPTION:

A single-page website built with HTML that introduces me, includes my goals for the course, and lists a few personal interests.

---

## DESIRED RESULTS:

A working `index.html` file with all required elements, paired with this scope statement, submitted together in a `.zip` file.

---

## EXCLUSIONS:

- No CSS
- No JavaScript
- No images
- No extra pages
